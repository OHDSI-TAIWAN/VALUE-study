test_that(".validateExecuteArgs passes with valid arguments", {
  expect_true(
    .validateExecuteArgs(
      cdmName = "TestSite",
      cdmDatabaseSchema = "cdm.schema",
      cohortDatabaseSchema = "write.schema",
      outputFolder = "~/out",
      startDate = as.Date("2005-01-01"),
      endDate = as.Date("2023-12-31"),
      ageMin = 18,
      ageMax = 49,
      minCellCount = 5
    )
  )
})

test_that(".validateExecuteArgs rejects endDate before startDate", {
  expect_error(
    .validateExecuteArgs(
      cdmName = "TestSite",
      cdmDatabaseSchema = "cdm.schema",
      cohortDatabaseSchema = "write.schema",
      outputFolder = "~/out",
      startDate = as.Date("2023-12-31"),
      endDate = as.Date("2005-01-01"),
      ageMin = 18,
      ageMax = 49,
      minCellCount = 5
    ),
    class = "rlang_error"
  )
})

test_that(".validateExecuteArgs rejects ageMax below ageMin", {
  expect_error(
    .validateExecuteArgs(
      cdmName = "TestSite",
      cdmDatabaseSchema = "cdm.schema",
      cohortDatabaseSchema = "write.schema",
      outputFolder = "~/out",
      startDate = as.Date("2005-01-01"),
      endDate = as.Date("2023-12-31"),
      ageMin = 49,
      ageMax = 18,
      minCellCount = 5
    )
  )
})

test_that(".validateExecuteArgs rejects empty cdmName", {
  expect_error(
    .validateExecuteArgs(
      cdmName = "",
      cdmDatabaseSchema = "cdm.schema",
      cohortDatabaseSchema = "write.schema",
      outputFolder = "~/out",
      startDate = as.Date("2005-01-01"),
      endDate = as.Date("2023-12-31"),
      ageMin = 18,
      ageMax = 49,
      minCellCount = 5
    )
  )
})

test_that(".validateExecuteArgs rejects negative minCellCount", {
  expect_error(
    .validateExecuteArgs(
      cdmName = "TestSite",
      cdmDatabaseSchema = "cdm.schema",
      cohortDatabaseSchema = "write.schema",
      outputFolder = "~/out",
      startDate = as.Date("2005-01-01"),
      endDate = as.Date("2023-12-31"),
      ageMin = 18,
      ageMax = 49,
      minCellCount = -1
    )
  )
})
