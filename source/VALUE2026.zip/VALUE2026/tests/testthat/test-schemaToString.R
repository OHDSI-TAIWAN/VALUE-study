test_that(".schemaToString passes through a single string schema", {
  expect_equal(.schemaToString("cdm"), "cdm")
})

test_that(".schemaToString joins catalog + schema vectors with a dot", {
  expect_equal(
    .schemaToString(c(catalog = "OHDSI_V4", schema = "dbo")),
    "OHDSI_V4.dbo"
  )
})
