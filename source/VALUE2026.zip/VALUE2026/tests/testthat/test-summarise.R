test_that("summarisePrevalence suppresses counts below minCellCount", {
  prevTidy <- dplyr::tibble(
    prevalence_start_date = as.Date(c("2020-01-01", "2020-01-01", "2021-01-01", "2021-01-01")),
    prevalence_end_date   = as.Date(c("2020-12-31", "2020-12-31", "2021-12-31", "2021-12-31")),
    denominator_sex       = c("Male", "Female", "Male", "Female"),
    denominator_count     = c(1000, 1000, 3, 1000),
    outcome_count         = c(50, 40, 2, 45),
    prevalence            = c(0.05, 0.04, 0.667, 0.045)
  )
  prevResult <- structure(list(), class = "fake_prevalence_result")

  testthat::local_mocked_bindings(
    tidy = function(x) prevTidy,
    .package = "omopgenerics"
  )

  result <- summarisePrevalence(
    prevalenceResult = prevResult,
    startDate = as.Date("2020-01-01"),
    endDate = as.Date("2021-12-31"),
    minCellCount = 5
  )

  # 2021 Male stratum had denominator_count = 3 (< 5) -> suppressed to NA
  row2021 <- result$bySex[result$bySex$Year == 2021, ]
  expect_true(is.na(row2021[["N total patients (male)"]]))
  expect_true(is.na(row2021[["N valproate users (male)"]]))
  expect_true(is.na(row2021[["Rate of valproate use (male)"]]))

  # 2020 Male stratum had denominator_count = 1000 (>= 5) -> retained
  row2020 <- result$bySex[result$bySex$Year == 2020, ]
  expect_equal(row2020[["N total patients (male)"]], 1000)
  expect_equal(row2020[["N valproate users (male)"]], 50)
})

test_that("summarisePrevalence fills in missing years via tidyr::complete", {
  prevTidy <- dplyr::tibble(
    prevalence_start_date = as.Date(c("2020-01-01", "2020-01-01")),
    prevalence_end_date   = as.Date(c("2020-12-31", "2020-12-31")),
    denominator_sex       = c("Male", "Female"),
    denominator_count     = c(1000, 1000),
    outcome_count         = c(50, 40),
    prevalence            = c(0.05, 0.04)
  )
  prevResult <- structure(list(), class = "fake_prevalence_result")

  testthat::local_mocked_bindings(
    tidy = function(x) prevTidy,
    .package = "omopgenerics"
  )

  result <- summarisePrevalence(
    prevalenceResult = prevResult,
    startDate = as.Date("2020-01-01"),
    endDate = as.Date("2022-12-31"),
    minCellCount = 5
  )

  # Study period spans 2020-2022, but data only has 2020 -> 2021/2022 should
  # still appear as rows (with NA values) thanks to tidyr::complete.
  expect_equal(result$bySex$Year, c(2020, 2021, 2022))
  expect_true(is.na(result$bySex[result$bySex$Year == 2022, ][["N total patients (male)"]]))
})
