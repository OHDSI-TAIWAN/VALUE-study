#' Baseline characterization of valproate users
#'
#' @description
#' Produces aggregate baseline characteristics of the valproate outcome
#' cohort (demographics, conditions, and drugs in the 365 days before cohort
#' start), matching Table 3 in Bellas et al. (2025).
#'
#' This uses [FeatureExtraction::getDbCovariateData()] directly rather than
#' `Characterization::runCharacterizationAnalyses()`, because Characterization
#' v3.0.1 generates an internal `characterization_target_id` that does not
#' match the cohort's `cohort_definition_id` (it maps `targetIds = 1` to
#' `characterization_target_id = 10`), causing it to silently find zero
#' patients. Querying `cohort_definition_id` directly with FeatureExtraction
#' avoids this mismatch entirely.
#'
#' @param connectionDetails A `connectionDetails` object from
#'   [DatabaseConnector::createConnectionDetails()], pointing at the same
#'   database as `cdm`.
#' @param cdmDatabaseSchema Fully-qualified CDM schema.
#' @param cohortDatabaseSchema Fully-qualified schema containing the outcome
#'   cohort table.
#' @param outcomeTableName Name of the outcome cohort table.
#' @param cohortId Cohort definition id to characterize within
#'   `outcomeTableName`. Defaults to `1L` (the valproate cohort, as generated
#'   by [generateCohorts()]).
#' @param tempEmulationSchema Schema used to emulate temp tables on DBMSs
#'   that need it, or `NULL`.
#' @param minCellCount Minimum cell count to report; smaller counts are
#'   suppressed (set to `NA`) before being returned. Defaults to `5`.
#'
#' @return A list with `table1` (a suppressed, publication-ready data frame)
#'   and `nPatients` (total patients characterized, for reference).
#' @export
runCharacterization <- function(connectionDetails,
                                 cdmDatabaseSchema,
                                 cohortDatabaseSchema,
                                 outcomeTableName = "value2026_outcome",
                                 cohortId = 1L,
                                 tempEmulationSchema = NULL,
                                 minCellCount = 5) {
  checkmate::assert_string(cdmDatabaseSchema)
  checkmate::assert_string(cohortDatabaseSchema)
  checkmate::assert_string(outcomeTableName)
  checkmate::assert_int(minCellCount, lower = 0)

  cli::cli_inform("Extracting baseline covariates for characterization...")

  covariateSettings <- FeatureExtraction::createCovariateSettings(
    useDemographicsGender        = TRUE,
    useDemographicsAge           = TRUE,
    useDemographicsAgeGroup      = TRUE,
    useDemographicsIndexYear     = TRUE,
    useConditionGroupEraLongTerm = TRUE,
    useDrugGroupEraLongTerm      = TRUE,
    useCharlsonIndex             = TRUE
  )

  covariateData <- FeatureExtraction::getDbCovariateData(
    connectionDetails    = connectionDetails,
    cdmDatabaseSchema    = cdmDatabaseSchema,
    cohortDatabaseSchema = cohortDatabaseSchema,
    cohortTable          = outcomeTableName,
    cohortIds            = cohortId,
    covariateSettings    = covariateSettings,
    aggregated           = TRUE,
    tempEmulationSchema  = tempEmulationSchema
  )

  con <- DatabaseConnector::connect(connectionDetails)
  on.exit(DatabaseConnector::disconnect(con))
  nPatients <- DatabaseConnector::renderTranslateQuerySql(
    connection = con,
    sql = "SELECT COUNT(DISTINCT subject_id) AS n
           FROM @cohort_database_schema.@outcome_table_name
           WHERE cohort_definition_id = @cohort_id",
    cohort_database_schema = cohortDatabaseSchema,
    outcome_table_name     = outcomeTableName,
    cohort_id              = cohortId,
    snakeCaseToCamelCase    = TRUE
  )$n
  cli::cli_inform(c("i" = "Total patients characterized: {nPatients}"))

  table1 <- FeatureExtraction::createTable1(
    covariateData1 = covariateData,
    output         = "one column",
    showCounts     = TRUE,
    showPercent    = TRUE,
    percentDigits  = 1,
    valueDigits    = 1
  )

  table1Suppressed <- table1 |>
    dplyr::filter(
      is.na(.data$Count) | as.numeric(gsub(",", "", .data$Count)) >= minCellCount
    )

  cli::cli_inform(c("v" = "Characterization complete ({nrow(table1Suppressed)} rows after suppression)."))

  list(table1 = table1Suppressed, nPatients = nPatients)
}
