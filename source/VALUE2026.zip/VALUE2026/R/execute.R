#' Run the full VALUE2026 study at a data partner site
#'
#' @description
#' Single entry point for the VALUE2026 study: generates the valproate
#' outcome cohort and denominator population, estimates incidence and period
#' prevalence, runs baseline characterization, builds the standard plots,
#' and exports all results to `outputFolder`. This is the only function most
#' collaborators need to call -- see `inst/CodeToRun.R` for a fill-in-the-blanks
#' template.
#'
#' No database credentials are read or stored by this package. Callers open
#' their own `con` (DBI) and `connectionDetails` (DatabaseConnector) using
#' their site's own credentials (e.g. from environment variables), and pass
#' them in.
#'
#' @param con An open DBI connection to the site's OMOP CDM database, used
#'   to build the `cdm_reference` (see [connectSite()]).
#' @param connectionDetails A `connectionDetails` object from
#'   [DatabaseConnector::createConnectionDetails()], pointing at the same
#'   database as `con`. Used for cohort generation and characterization,
#'   which require DatabaseConnector's JDBC path (see [generateCohorts()]
#'   and [runCharacterization()] for why).
#' @param cdmName Short display name for the database (e.g. `"TMUCRD"`).
#' @param cdmDatabaseSchema Schema containing the OMOP CDM tables. Either a
#'   plain string (e.g. `"cdm"`) or a named `c(catalog = ..., schema = ...)`
#'   vector for databases that use catalogs (e.g. SQL Server).
#' @param vocabularyDatabaseSchema Schema containing the OMOP vocabulary
#'   tables. Same format as `cdmDatabaseSchema`.
#' @param writeDatabaseSchema Schema the site has write access to, for study
#'   tables (cohorts, denominators, results). Same format as
#'   `cdmDatabaseSchema`.
#' @param writePrefix Table name prefix used for study tables written to
#'   `writeDatabaseSchema`. Defaults to `"value2026_"`.
#' @param outputFolder Local directory to write CSV/Excel/plot results to.
#'   Created if it does not exist.
#' @param startDate,endDate Study period bounds. Defaults match the VALUE
#'   study protocol (`2005-01-01` to `2023-12-31`); adjust per your site's
#'   data coverage.
#' @param ageMin,ageMax Age bounds for the denominator population. Defaults
#'   to `18`-`49` per protocol.
#' @param sex Character vector of sex strata. Defaults to
#'   `c("Both", "Female", "Male")`.
#' @param daysPriorObservation Minimum required prior observation (days) for
#'   the denominator. Defaults to `365`.
#' @param outcomeWashout Washout period (days) for incident valproate use.
#'   Defaults to `365`.
#' @param tempEmulationSchema Schema used to emulate temp tables on DBMSs
#'   that need it, or `NULL` if not needed for your site's DBMS.
#' @param minCellCount Minimum cell count to report anywhere in the exported
#'   results; smaller counts are suppressed. Defaults to `5`.
#' @param characterize Whether to run baseline characterization (Table 1).
#'   Defaults to `TRUE`; set `FALSE` to skip if FeatureExtraction is
#'   unavailable at your site.
#' @param drugUtilisation Whether to run drug utilization analyses (summary,
#'   trends by year, prescription rate, exposure per patient). Defaults to
#'   `TRUE`; set `FALSE` to skip if the DrugUtilisation package is
#'   unavailable at your site.
#' @param ingredientConceptId RxNorm ingredient concept id for valproate,
#'   used for drug utilization analyses. Defaults to `745466`.
#' @param gapEra Maximum gap (days) between prescriptions to still be
#'   concatenated into one continuous treatment era, for drug utilization
#'   analyses. Defaults to `30`.
#'
#' @return (Invisibly) a list with the raw incidence result, prevalence
#'   result, prevalence summary tables, characterization table (if run),
#'   drug utilization results (if run), and the `outputFolder` path.
#' @export
execute <- function(con,
                     connectionDetails,
                     cdmName,
                     cdmDatabaseSchema,
                     vocabularyDatabaseSchema,
                     writeDatabaseSchema,
                     writePrefix = "value2026_",
                     outputFolder,
                     startDate = as.Date("2005-01-01"),
                     endDate = as.Date("2023-12-31"),
                     ageMin = 18,
                     ageMax = 49,
                     sex = c("Both", "Female", "Male"),
                     daysPriorObservation = 365,
                     outcomeWashout = 365,
                     tempEmulationSchema = NULL,
                     minCellCount = 5,
                     characterize = TRUE,
                     drugUtilisation = TRUE,
                     ingredientConceptId = 745466,
                     gapEra = 30) {
  .validateExecuteArgs(
    cdmName              = cdmName,
    cdmDatabaseSchema    = .schemaToString(cdmDatabaseSchema),
    cohortDatabaseSchema = .schemaToString(writeDatabaseSchema),
    outputFolder         = outputFolder,
    startDate            = startDate,
    endDate              = endDate,
    ageMin               = ageMin,
    ageMax               = ageMax,
    minCellCount         = minCellCount
  )

  cdmSchemaStr   <- .schemaToString(cdmDatabaseSchema)
  writeSchemaStr <- .schemaToString(writeDatabaseSchema)
  outcomeTable   <- paste0(writePrefix, "outcome")
  denominatorName <- paste0(writePrefix, "denominator")

  cli::cli_h1("VALUE2026: {cdmName}")

  cdm <- connectSite(
    con              = con,
    cdmName          = cdmName,
    cdmSchema        = cdmDatabaseSchema,
    vocabularySchema = vocabularyDatabaseSchema,
    writeSchema      = writeDatabaseSchema,
    writePrefix      = writePrefix
  )

  cdm <- generateCohorts(
    cdm                   = cdm,
    connectionDetails     = connectionDetails,
    cdmDatabaseSchema     = cdmSchemaStr,
    cohortDatabaseSchema  = writeSchemaStr,
    tempEmulationSchema   = tempEmulationSchema,
    outcomeTableName      = outcomeTable
  )

  cdm <- generateDenominator(
    cdm                  = cdm,
    startDate            = startDate,
    endDate              = endDate,
    ageMin               = ageMin,
    ageMax               = ageMax,
    sex                  = sex,
    daysPriorObservation = daysPriorObservation,
    denominatorName      = denominatorName
  )

  inc <- estimateStudyIncidence(
    cdm              = cdm,
    denominatorTable = denominatorName,
    outcomeTable     = outcomeTable,
    outcomeWashout   = outcomeWashout
  )

  prev <- estimateStudyPrevalence(
    cdm              = cdm,
    denominatorTable = denominatorName,
    outcomeTable     = outcomeTable
  )

  prevSummary <- summarisePrevalence(
    prevalenceResult = prev,
    startDate        = startDate,
    endDate          = endDate,
    minCellCount     = minCellCount
  )

  table1 <- NULL
  if (isTRUE(characterize)) {
    charResult <- runCharacterization(
      connectionDetails    = connectionDetails,
      cdmDatabaseSchema    = cdmSchemaStr,
      cohortDatabaseSchema = writeSchemaStr,
      outcomeTableName     = outcomeTable,
      cohortId             = 1L,
      tempEmulationSchema  = tempEmulationSchema,
      minCellCount         = minCellCount
    )
    table1 <- charResult$table1
  }

  plots <- list(
    Incidence_by_sex        = plotIncidenceBySex(inc, cdmName, ageMin, ageMax, startDate, endDate),
    Incidence_person_years  = plotIncidencePersonYears(inc, ageMin, ageMax),
    Prevalence_by_sex       = plotPrevalenceBySex(prev, cdmName, ageMin, ageMax, startDate, endDate)
  )

  drugUtilisationTidy  <- NULL
  drugUtilisationByYear <- NULL
  prescriptionRate      <- NULL
  exposurePerPatient    <- NULL
  if (isTRUE(drugUtilisation)) {
    dusResult <- summariseStudyDrugUtilisation(
      cdm                  = cdm,
      outcomeTable         = outcomeTable,
      ingredientConceptId  = ingredientConceptId,
      gapEra               = gapEra
    )
    drugUtilisationTidy <- tidyDrugUtilisation(dusResult)

    drugUtilisationByYear <- summariseDrugUtilisationByYear(
      cdm                  = cdm,
      outcomeTable         = outcomeTable,
      ingredientConceptId  = ingredientConceptId,
      gapEra               = gapEra,
      startDate            = startDate
    )

    prescriptionRate <- summarisePrescriptionRate(
      con                 = con,
      cdmDatabaseSchema   = cdmDatabaseSchema,
      ingredientConceptId = ingredientConceptId,
      startDate           = startDate,
      endDate             = endDate,
      prevalenceSummary   = prevSummary
    )

    exposurePerPatient <- summariseExposurePerPatient(
      con                 = con,
      cdmDatabaseSchema   = cdmDatabaseSchema,
      ingredientConceptId = ingredientConceptId,
      startDate           = startDate,
      endDate             = endDate
    )

    nPatients <- sum(omopgenerics::cohortCount(cdm[[outcomeTable]])$number_records)

    plots$Drug_Utilization_Summary <- plotDrugUtilisationSummary(
      drugUtilisationTidy = drugUtilisationTidy,
      nPatients           = nPatients,
      cdmName             = cdmName,
      startDate           = startDate,
      endDate             = endDate
    )
    plots$Drug_Utilization_Trends_by_Year <- plotDrugUtilisationTrendsByYear(
      drugUtilisationByYear = drugUtilisationByYear,
      cdmName               = cdmName,
      ageMin                = ageMin,
      ageMax                = ageMax,
      startDate             = startDate,
      endDate               = endDate
    )
    plots$Prescription_Rate_Both <- plotPrescriptionRate(
      rate = prescriptionRate$overall, cdmName = cdmName,
      ageMin = ageMin, ageMax = ageMax, startDate = startDate, endDate = endDate
    )
    plots$Prescription_Rate_by_Sex <- plotPrescriptionRateBySex(
      rateBySex = prescriptionRate$bySex, cdmName = cdmName,
      ageMin = ageMin, ageMax = ageMax, startDate = startDate, endDate = endDate
    )
    plots$Exposure_per_Patient_Both <- plotExposurePerPatient(
      exposurePerPatient = exposurePerPatient$overall, cdmName = cdmName,
      ageMin = ageMin, ageMax = ageMax, startDate = startDate, endDate = endDate
    )
    plots$Exposure_per_Patient_by_Sex <- plotExposurePerPatientBySex(
      exposurePerPatientBySex = exposurePerPatient$bySex, cdmName = cdmName,
      ageMin = ageMin, ageMax = ageMax, startDate = startDate, endDate = endDate
    )
  }

  exportResults(
    outputFolder          = outputFolder,
    prevalenceSummary     = prevSummary,
    table1                = table1,
    plots                 = plots,
    drugUtilisationTidy   = drugUtilisationTidy,
    drugUtilisationByYear = drugUtilisationByYear,
    prescriptionRate      = prescriptionRate,
    exposurePerPatient    = exposurePerPatient
  )

  CDMConnector::cdmDisconnect(cdm)

  cli::cli_h1("VALUE2026: {cdmName} complete")
  cli::cli_inform(c("v" = "Results written to {.path {outputFolder}}"))

  invisible(list(
    incidence             = inc,
    prevalence            = prev,
    prevalenceSummary     = prevSummary,
    table1                = table1,
    drugUtilisationTidy   = drugUtilisationTidy,
    drugUtilisationByYear = drugUtilisationByYear,
    prescriptionRate      = prescriptionRate,
    exposurePerPatient    = exposurePerPatient,
    outputFolder          = outputFolder
  ))
}

#' @noRd
.schemaToString <- function(schema) {
  if (length(schema) == 1) {
    return(unname(schema))
  }
  paste(unname(schema), collapse = ".")
}
