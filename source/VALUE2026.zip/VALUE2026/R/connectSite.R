#' Build a CDM reference for a participating site
#'
#' @description
#' Wraps [CDMConnector::cdmFromCon()] to build the CDM reference used by the
#' rest of the VALUE2026 pipeline. No credentials are read, stored, or
#' defaulted here -- the caller (each site's `CodeToRun.R`) supplies its own
#' open DBI connection and schema names.
#'
#' @param con A DBI connection to the site's OMOP CDM database (e.g. from
#'   `DBI::dbConnect()`). The caller owns the connection's lifecycle.
#' @param cdmName A short display name for the database (e.g. `"TMUCRD"`).
#' @param cdmSchema Schema containing the OMOP CDM tables. Either a single
#'   string or a named `c(catalog = ..., schema = ...)` vector for databases
#'   that use catalogs (e.g. SQL Server).
#' @param vocabularySchema Schema containing the OMOP vocabulary tables.
#'   Same format as `cdmSchema`.
#' @param writeSchema Schema the site has write access to, for intermediate
#'   study tables (cohorts, denominators). Same format as `cdmSchema`.
#' @param writePrefix Table name prefix used for all study tables written to
#'   `writeSchema`, to avoid collisions with other studies. Defaults to
#'   `"value2026_"`.
#'
#' @return A `cdm_reference` object, as used by CDMConnector/omopgenerics.
#' @export
connectSite <- function(con,
                         cdmName,
                         cdmSchema,
                         vocabularySchema,
                         writeSchema,
                         writePrefix = "value2026_") {
  checkmate::assert_string(cdmName)
  checkmate::assert_string(writePrefix)

  cli::cli_inform("Building CDM reference for {.val {cdmName}}...")

  cdm <- CDMConnector::cdmFromCon(
    con              = con,
    cdmName          = cdmName,
    cdmSchema        = cdmSchema,
    vocabularySchema = vocabularySchema,
    writeSchema      = c(writeSchema, prefix = writePrefix)
  )

  cli::cli_inform(c("v" = "CDM reference for {.val {cdmName}} ready."))
  cdm
}
