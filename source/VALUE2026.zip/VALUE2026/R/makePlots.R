#' @noRd
.sexColours <- c(Both = "#00BA38", Female = "#F8766D", Male = "#619CFF")

#' Plot annual incidence rates by sex
#'
#' @param incidenceResult An incidence result from [estimateStudyIncidence()].
#' @param cdmName Display name of the database, used in the plot title.
#' @param ageMin,ageMax Age bounds used in the plot title.
#' @param startDate,endDate Study period bounds, used in the plot title.
#'
#' @return A `ggplot` object.
#' @export
plotIncidenceBySex <- function(incidenceResult, cdmName, ageMin, ageMax, startDate, endDate) {
  incTidy <- incidenceResult |>
    omopgenerics::tidy() |>
    dplyr::filter(!is.na(.data$incidence_100000_pys)) |>
    dplyr::mutate(
      year          = as.integer(format(as.Date(.data$incidence_start_date), "%Y")),
      ir_100k       = as.numeric(.data$incidence_100000_pys),
      ir_lower_100k = as.numeric(.data$incidence_100000_pys_95CI_lower),
      ir_upper_100k = as.numeric(.data$incidence_100000_pys_95CI_upper),
      sex           = factor(.data$denominator_sex, levels = c("Both", "Female", "Male"))
    ) |>
    dplyr::filter(!is.na(.data$ir_100k))

  ggplot2::ggplot(incTidy, ggplot2::aes(x = .data$year, y = .data$ir_100k, colour = .data$sex, group = .data$sex)) +
    ggplot2::geom_errorbar(
      ggplot2::aes(ymin = .data$ir_lower_100k, ymax = .data$ir_upper_100k),
      width = 0.3, linewidth = 0.8, position = ggplot2::position_dodge(width = 0.5)
    ) +
    ggplot2::geom_point(size = 3.5, position = ggplot2::position_dodge(width = 0.5)) +
    ggplot2::scale_colour_manual(values = .sexColours, name = "Sex") +
    ggplot2::scale_x_continuous(
      breaks = seq(min(incTidy$year), max(incTidy$year), by = 1),
      expand = ggplot2::expansion(mult = c(0.03, 0.03))
    ) +
    ggplot2::scale_y_continuous(
      labels = scales::label_comma(), limits = c(0, NA),
      expand = ggplot2::expansion(mult = c(0.02, 0.08))
    ) +
    ggplot2::labs(
      title    = paste0("Annual incidence rates of valproate use, ages ", ageMin,
                        "-", ageMax, " (", cdmName, ", ", format(startDate, "%Y"),
                        "-", format(endDate, "%Y"), ")"),
      subtitle = "New users per 100,000 person-years (95% CI); 365-day washout",
      x = "Year", y = "Incidence (per 100,000 person-years)"
    ) +
    ggplot2::theme_bw(base_size = 15) +
    ggplot2::theme(
      legend.position  = "bottom",
      legend.title     = ggplot2::element_text(size = 13, face = "bold"),
      legend.text      = ggplot2::element_text(size = 12),
      plot.title       = ggplot2::element_text(size = 14, face = "bold", hjust = 0),
      plot.subtitle    = ggplot2::element_text(size = 12, colour = "grey40", hjust = 0),
      axis.text.x      = ggplot2::element_text(size = 11, angle = 45, hjust = 1),
      axis.text.y      = ggplot2::element_text(size = 12),
      axis.title       = ggplot2::element_text(size = 13),
      panel.grid.major = ggplot2::element_line(colour = "grey90"),
      panel.grid.minor = ggplot2::element_blank()
    )
}

#' Plot person-years contributed by calendar year
#'
#' @inheritParams plotIncidenceBySex
#'
#' @return A `ggplot` object.
#' @export
plotIncidencePersonYears <- function(incidenceResult, ageMin, ageMax) {
  incTidy <- incidenceResult |>
    omopgenerics::tidy() |>
    dplyr::filter(!is.na(.data$incidence_100000_pys)) |>
    dplyr::mutate(year = as.integer(format(as.Date(.data$incidence_start_date), "%Y")))

  IncidencePrevalence::plotIncidencePopulation(result = incidenceResult, y = "person_years") +
    ggplot2::scale_x_continuous(
      breaks = seq(min(incTidy$year), max(incTidy$year), by = 1),
      expand = ggplot2::expansion(mult = c(0.01, 0.02))
    ) +
    ggplot2::scale_y_continuous(
      labels = function(x) paste0(x / 1000, "k"),
      expand = ggplot2::expansion(mult = c(0, 0.08))
    ) +
    ggplot2::labs(
      title = paste0("Person-years by calendar year (Ages ", ageMin, "-", ageMax, ")"),
      x = "Year", y = "Person-years"
    ) +
    ggplot2::theme_minimal(base_size = 15) +
    ggplot2::theme(
      legend.position    = "none",
      plot.title         = ggplot2::element_text(size = 16, face = "bold", hjust = 0),
      axis.title         = ggplot2::element_text(size = 15),
      axis.text.x        = ggplot2::element_text(size = 12, angle = 45, hjust = 1),
      axis.text.y        = ggplot2::element_text(size = 12),
      panel.grid.major.x = ggplot2::element_blank(),
      panel.grid.minor   = ggplot2::element_blank(),
      panel.grid.major.y = ggplot2::element_line(color = "grey85", linewidth = 0.4),
      plot.margin        = ggplot2::margin(12, 18, 12, 12)
    )
}

#' Plot annual period prevalence by sex
#'
#' @param prevalenceResult A period prevalence result from
#'   [estimateStudyPrevalence()].
#' @inheritParams plotIncidenceBySex
#'
#' @return A `ggplot` object.
#' @export
plotPrevalenceBySex <- function(prevalenceResult, cdmName, ageMin, ageMax, startDate, endDate) {
  prevTidy <- prevalenceResult |>
    omopgenerics::tidy() |>
    dplyr::filter(!is.na(.data$prevalence)) |>
    dplyr::mutate(
      year      = as.integer(format(as.Date(.data$prevalence_start_date), "%Y")),
      prev_pct  = as.numeric(.data$prevalence),
      prev_low  = as.numeric(.data$prevalence_95CI_lower),
      prev_high = as.numeric(.data$prevalence_95CI_upper),
      sex       = factor(.data$denominator_sex, levels = c("Both", "Female", "Male"))
    ) |>
    dplyr::filter(!is.na(.data$prev_pct), !is.na(.data$sex))

  ggplot2::ggplot(prevTidy, ggplot2::aes(x = .data$year, y = .data$prev_pct, colour = .data$sex, group = .data$sex)) +
    ggplot2::geom_errorbar(
      ggplot2::aes(ymin = .data$prev_low, ymax = .data$prev_high),
      width = 0.3, linewidth = 0.8, position = ggplot2::position_dodge(width = 0.5)
    ) +
    ggplot2::geom_point(size = 3.5, position = ggplot2::position_dodge(width = 0.5)) +
    ggplot2::scale_colour_manual(values = .sexColours, name = "Sex") +
    ggplot2::scale_x_continuous(
      breaks = seq(min(prevTidy$year), max(prevTidy$year), by = 1),
      expand = ggplot2::expansion(mult = c(0.03, 0.03))
    ) +
    ggplot2::scale_y_continuous(
      labels = scales::label_percent(accuracy = 0.01), limits = c(0, NA),
      expand = ggplot2::expansion(mult = c(0.02, 0.08))
    ) +
    ggplot2::labs(
      title    = paste0("Annual period prevalence of valproate use, ages ", ageMin,
                        "-", ageMax, " (", cdmName, ", ", format(startDate, "%Y"),
                        "-", format(endDate, "%Y"), ")"),
      subtitle = "Proportion with any valproate use during each calendar year (95% CI)",
      x = "Year", y = "Prevalence"
    ) +
    ggplot2::theme_bw(base_size = 15) +
    ggplot2::theme(
      legend.position  = "bottom",
      legend.title     = ggplot2::element_text(size = 13, face = "bold"),
      legend.text      = ggplot2::element_text(size = 12),
      plot.title       = ggplot2::element_text(size = 14, face = "bold", hjust = 0),
      plot.subtitle    = ggplot2::element_text(size = 12, colour = "grey40", hjust = 0),
      axis.text.x      = ggplot2::element_text(size = 11, angle = 45, hjust = 1),
      axis.text.y      = ggplot2::element_text(size = 12),
      axis.title       = ggplot2::element_text(size = 13),
      panel.grid.major = ggplot2::element_line(colour = "grey90"),
      panel.grid.minor = ggplot2::element_blank()
    )
}

#' Plot drug utilization summary (median + IQR per metric)
#'
#' @param drugUtilisationTidy A tidy drug utilization table from
#'   [tidyDrugUtilisation()].
#' @param nPatients Number of patients characterized, shown in the subtitle.
#' @param cdmName,startDate,endDate Used in the plot subtitle.
#'
#' @return A `ggplot` object.
#' @export
plotDrugUtilisationSummary <- function(drugUtilisationTidy, nPatients, cdmName, startDate, endDate) {
  plotVars <- c(
    "days prescribed", "days exposed", "initial exposure duration",
    "number eras", "number exposures", "time to exposure"
  )
  varLabels <- c(
    "days prescribed"            = "Days prescribed",
    "days exposed"               = "Days exposed",
    "initial exposure duration"  = "Initial exposure\nduration (days)",
    "number eras"                = "Number of eras",
    "number exposures"           = "Number of\nexposures",
    "time to exposure"           = "Time to\nexposure (days)"
  )

  plotData <- drugUtilisationTidy |>
    dplyr::filter(.data$Variable %in% plotVars) |>
    tidyr::pivot_wider(names_from = "Estimate", values_from = "Value") |>
    dplyr::mutate(
      label = dplyr::recode(.data$Variable, !!!varLabels),
      label = factor(.data$label, levels = varLabels[plotVars])
    )

  ggplot2::ggplot(plotData, ggplot2::aes(x = .data$label, y = .data$median)) +
    ggplot2::geom_errorbar(
      ggplot2::aes(ymin = .data$q25, ymax = .data$q75),
      width = 0.25, linewidth = 0.9, colour = "#2C7BB6"
    ) +
    ggplot2::geom_point(size = 4, colour = "#2C7BB6") +
    ggplot2::geom_text(
      ggplot2::aes(label = paste0("Median: ", .data$median)),
      vjust = -1.2, size = 3.8, colour = "grey30"
    ) +
    ggplot2::labs(
      title    = paste0("Valproate drug utilization summary (", cdmName, ", ",
                        format(startDate, "%Y"), "-", format(endDate, "%Y"), ")"),
      subtitle = paste0("N = ", format(nPatients, big.mark = ","), " patients | Dot = median, bars = IQR (Q25-Q75)"),
      x = NULL, y = "Value"
    ) +
    ggplot2::theme_bw(base_size = 14) +
    ggplot2::theme(
      plot.title          = ggplot2::element_text(size = 14, face = "bold", hjust = 0),
      plot.subtitle       = ggplot2::element_text(size = 11, colour = "grey40", hjust = 0),
      axis.text.x         = ggplot2::element_text(size = 11),
      axis.text.y         = ggplot2::element_text(size = 11),
      axis.title.y        = ggplot2::element_text(size = 12),
      panel.grid.major.x  = ggplot2::element_blank(),
      panel.grid.minor    = ggplot2::element_blank(),
      panel.grid.major.y  = ggplot2::element_line(colour = "grey90")
    )
}

#' Plot drug utilization trends over calendar years
#'
#' @param drugUtilisationByYear A tibble from
#'   [summariseDrugUtilisationByYear()].
#' @param cdmName Display name of the database, used in the plot subtitle.
#' @param ageMin,ageMax Age bounds used in the plot subtitle.
#' @param startDate,endDate Study period bounds, used for x-axis breaks.
#'
#' @return A `ggplot` object.
#' @export
plotDrugUtilisationTrendsByYear <- function(drugUtilisationByYear, cdmName, ageMin, ageMax, startDate, endDate) {
  ggplot2::ggplot(drugUtilisationByYear, ggplot2::aes(x = .data$year, y = .data$value)) +
    ggplot2::geom_line(colour = "#2C7BB6", linewidth = 0.9) +
    ggplot2::geom_point(size = 2.5, colour = "#2C7BB6") +
    ggplot2::facet_wrap(~ .data$variable_name, scales = "free_y", ncol = 2) +
    ggplot2::scale_x_continuous(
      breaks = seq(as.integer(format(startDate, "%Y")), as.integer(format(endDate, "%Y")), by = 2)
    ) +
    ggplot2::labs(
      title    = paste0("Valproate drug utilization trends over time (", cdmName, ")"),
      subtitle = paste0("Median values by index year, ages ", ageMin, "-", ageMax),
      x = "Year", y = "Median value"
    ) +
    ggplot2::theme_bw(base_size = 13) +
    ggplot2::theme(
      plot.title        = ggplot2::element_text(size = 14, face = "bold", hjust = 0),
      plot.subtitle     = ggplot2::element_text(size = 11, colour = "grey40", hjust = 0),
      strip.text        = ggplot2::element_text(size = 11, face = "bold"),
      strip.background  = ggplot2::element_rect(fill = "grey92", colour = NA),
      axis.text.x       = ggplot2::element_text(size = 10, angle = 45, hjust = 1),
      axis.text.y       = ggplot2::element_text(size = 10),
      panel.grid.minor  = ggplot2::element_blank(),
      panel.grid.major  = ggplot2::element_line(colour = "grey90"),
      panel.spacing     = grid::unit(1.2, "lines")
    )
}

#' Plot valproate prescription rate per 1,000 population
#'
#' @param rate A tibble from `summarisePrescriptionRate()$overall`.
#' @param cdmName Display name of the database, used in the plot title.
#' @param ageMin,ageMax Age bounds used in the plot subtitle.
#' @param startDate,endDate Study period bounds, used in the plot title.
#'
#' @return A `ggplot` object.
#' @export
plotPrescriptionRate <- function(rate, cdmName, ageMin, ageMax, startDate, endDate) {
  ggplot2::ggplot(rate, ggplot2::aes(x = .data$year, y = .data$rate_per_1000)) +
    ggplot2::geom_line(colour = "#2C7BB6", linewidth = 1) +
    ggplot2::geom_point(size = 3, colour = "#2C7BB6") +
    ggplot2::scale_x_continuous(
      breaks = seq(as.integer(format(startDate, "%Y")), as.integer(format(endDate, "%Y")), by = 1)
    ) +
    ggplot2::scale_y_continuous(limits = c(0, NA), expand = ggplot2::expansion(mult = c(0, 0.08))) +
    ggplot2::labs(
      title    = paste0("Valproate prescription rate (", cdmName, ", ",
                        format(startDate, "%Y"), "-", format(endDate, "%Y"), ")"),
      subtitle = paste0("Prescriptions per 1,000 population, ages ", ageMin, "-", ageMax, ", both sexes"),
      x = "Year", y = "Prescriptions per 1,000 population"
    ) +
    ggplot2::theme_bw(base_size = 14) +
    ggplot2::theme(
      plot.title       = ggplot2::element_text(size = 14, face = "bold", hjust = 0),
      plot.subtitle    = ggplot2::element_text(size = 11, colour = "grey40", hjust = 0),
      axis.text.x      = ggplot2::element_text(size = 11, angle = 45, hjust = 1),
      axis.text.y      = ggplot2::element_text(size = 11),
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major = ggplot2::element_line(colour = "grey90")
    )
}

#' Plot valproate prescription rate per 1,000 population, by sex
#'
#' @inheritParams plotPrescriptionRate
#' @param rateBySex A tibble from `summarisePrescriptionRate()$bySex`.
#'
#' @return A `ggplot` object.
#' @export
plotPrescriptionRateBySex <- function(rateBySex, cdmName, ageMin, ageMax, startDate, endDate) {
  ggplot2::ggplot(
    rateBySex, ggplot2::aes(x = .data$year, y = .data$rate_per_1000, colour = .data$Sex, group = .data$Sex)
  ) +
    ggplot2::geom_line(linewidth = 1) +
    ggplot2::geom_point(size = 3) +
    ggplot2::scale_colour_manual(values = c(Female = "#00BA38", Male = "#619CFF"), name = "Sex") +
    ggplot2::scale_x_continuous(
      breaks = seq(as.integer(format(startDate, "%Y")), as.integer(format(endDate, "%Y")), by = 1)
    ) +
    ggplot2::scale_y_continuous(limits = c(0, NA), expand = ggplot2::expansion(mult = c(0, 0.08))) +
    ggplot2::labs(
      title    = paste0("Valproate prescription rate by sex (", cdmName, ", ",
                        format(startDate, "%Y"), "-", format(endDate, "%Y"), ")"),
      subtitle = paste0("Prescriptions per 1,000 population, ages ", ageMin, "-", ageMax),
      x = "Year", y = "Prescriptions per 1,000 population"
    ) +
    ggplot2::theme_bw(base_size = 14) +
    ggplot2::theme(
      legend.position  = "bottom",
      legend.title     = ggplot2::element_text(size = 13, face = "bold"),
      legend.text      = ggplot2::element_text(size = 12),
      plot.title       = ggplot2::element_text(size = 14, face = "bold", hjust = 0),
      plot.subtitle    = ggplot2::element_text(size = 11, colour = "grey40", hjust = 0),
      axis.text.x      = ggplot2::element_text(size = 11, angle = 45, hjust = 1),
      axis.text.y      = ggplot2::element_text(size = 11),
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major = ggplot2::element_line(colour = "grey90")
    )
}

#' Plot valproate exposure records per patient per year
#'
#' @param exposurePerPatient A tibble from
#'   `summariseExposurePerPatient()$overall`.
#' @param cdmName Display name of the database, used in the plot title.
#' @param ageMin,ageMax Age bounds used in the plot subtitle.
#' @param startDate,endDate Study period bounds, used in the plot title.
#'
#' @return A `ggplot` object.
#' @export
plotExposurePerPatient <- function(exposurePerPatient, cdmName, ageMin, ageMax, startDate, endDate) {
  ggplot2::ggplot(exposurePerPatient, ggplot2::aes(x = .data$year, y = .data$rx_per_patient)) +
    ggplot2::geom_line(colour = "#D95F02", linewidth = 1) +
    ggplot2::geom_point(size = 3, colour = "#D95F02") +
    ggplot2::scale_x_continuous(
      breaks = seq(as.integer(format(startDate, "%Y")), as.integer(format(endDate, "%Y")), by = 1)
    ) +
    ggplot2::scale_y_continuous(limits = c(0, NA), expand = ggplot2::expansion(mult = c(0, 0.08))) +
    ggplot2::labs(
      title    = paste0("Valproate exposure records per patient per year (", cdmName, ", ",
                        format(startDate, "%Y"), "-", format(endDate, "%Y"), ")"),
      subtitle = paste0("Average drug_exposure records per valproate user, ages ", ageMin, "-", ageMax, ", both sexes"),
      x = "Year", y = "Exposure records per patient"
    ) +
    ggplot2::theme_bw(base_size = 14) +
    ggplot2::theme(
      plot.title       = ggplot2::element_text(size = 14, face = "bold", hjust = 0),
      plot.subtitle    = ggplot2::element_text(size = 11, colour = "grey40", hjust = 0),
      axis.text.x      = ggplot2::element_text(size = 11, angle = 45, hjust = 1),
      axis.text.y      = ggplot2::element_text(size = 11),
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major = ggplot2::element_line(colour = "grey90")
    )
}

#' Plot valproate exposure records per patient per year, by sex
#'
#' @inheritParams plotExposurePerPatient
#' @param exposurePerPatientBySex A tibble from
#'   `summariseExposurePerPatient()$bySex`.
#'
#' @return A `ggplot` object.
#' @export
plotExposurePerPatientBySex <- function(exposurePerPatientBySex, cdmName, ageMin, ageMax, startDate, endDate) {
  ggplot2::ggplot(
    exposurePerPatientBySex,
    ggplot2::aes(x = .data$year, y = .data$rx_per_patient, colour = .data$Sex, group = .data$Sex)
  ) +
    ggplot2::geom_line(linewidth = 1) +
    ggplot2::geom_point(size = 3) +
    ggplot2::scale_colour_manual(values = c(Female = "#F8766D", Male = "#619CFF"), name = "Sex") +
    ggplot2::scale_x_continuous(
      breaks = seq(as.integer(format(startDate, "%Y")), as.integer(format(endDate, "%Y")), by = 1)
    ) +
    ggplot2::scale_y_continuous(limits = c(0, NA), expand = ggplot2::expansion(mult = c(0, 0.08))) +
    ggplot2::labs(
      title    = paste0("Valproate exposure records per patient by sex (", cdmName, ", ",
                        format(startDate, "%Y"), "-", format(endDate, "%Y"), ")"),
      subtitle = paste0("Average drug_exposure records per valproate user, ages ", ageMin, "-", ageMax),
      x = "Year", y = "Exposure records per patient"
    ) +
    ggplot2::theme_bw(base_size = 14) +
    ggplot2::theme(
      legend.position  = "bottom",
      legend.title     = ggplot2::element_text(size = 13, face = "bold"),
      legend.text      = ggplot2::element_text(size = 12),
      plot.title       = ggplot2::element_text(size = 14, face = "bold", hjust = 0),
      plot.subtitle    = ggplot2::element_text(size = 11, colour = "grey40", hjust = 0),
      axis.text.x      = ggplot2::element_text(size = 11, angle = 45, hjust = 1),
      axis.text.y      = ggplot2::element_text(size = 11),
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major = ggplot2::element_line(colour = "grey90")
    )
}
