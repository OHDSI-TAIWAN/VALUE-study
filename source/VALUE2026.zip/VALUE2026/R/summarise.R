#' Build the annual prevalence summary tables
#'
#' @description
#' Collapses a period prevalence result into a wide annual summary
#' (Male / Female / Both), applying minimum cell count suppression, matching
#' the study's shared output format across data collaborators.
#'
#' @param prevalenceResult A period prevalence result from
#'   [estimateStudyPrevalence()].
#' @param startDate,endDate Study period bounds (`Date`), used to ensure
#'   every year in range appears in the output even if suppressed/missing.
#' @param minCellCount Minimum cell count to report; smaller counts are
#'   suppressed (set to `NA`) before being returned. Defaults to `5`.
#'
#' @return A list with two tibbles:
#'   \describe{
#'     \item{`bySex`}{One row per year, with Male and Female columns side by side.}
#'     \item{`bothSexes`}{One row per year, for the combined "Both" stratum.}
#'   }
#' @export
summarisePrevalence <- function(prevalenceResult, startDate, endDate, minCellCount = 5) {
  checkmate::assert_date(startDate)
  checkmate::assert_date(endDate)
  checkmate::assert_int(minCellCount, lower = 0)

  cli::cli_inform("Summarising prevalence into annual Male/Female/Both tables...")

  prevTidy <- prevalenceResult |> omopgenerics::tidy()

  prevCollapsed <- prevTidy |>
    dplyr::filter(!is.na(.data$prevalence_start_date)) |>
    dplyr::group_by(.data$prevalence_start_date, .data$denominator_sex) |>
    dplyr::summarise(
      denominator_count = dplyr::first(stats::na.omit(.data$denominator_count)),
      outcome_count      = dplyr::first(stats::na.omit(.data$outcome_count)),
      prevalence         = dplyr::first(stats::na.omit(.data$prevalence)),
      .groups = "drop"
    )

  yearSeq <- seq(
    as.integer(format(startDate, "%Y")),
    as.integer(format(endDate, "%Y")),
    by = 1
  )

  maleTbl   <- .makeSexTable(prevCollapsed, "Male",   "male",   minCellCount)
  femaleTbl <- .makeSexTable(prevCollapsed, "Female", "female", minCellCount)
  bothTbl   <- .makeSexTable(prevCollapsed, "Both",   "both",   minCellCount)

  bySex <- dplyr::full_join(maleTbl, femaleTbl, by = "Year") |>
    dplyr::arrange(.data$Year) |>
    tidyr::complete(Year = yearSeq)

  bothSexes <- bothTbl |>
    tidyr::complete(Year = yearSeq)

  cli::cli_inform(c("v" = "Prevalence summary tables built ({length(yearSeq)} years)."))

  list(bySex = bySex, bothSexes = bothSexes)
}

#' @noRd
.makeSexTable <- function(data, sexLabel, colSuffix, minCellCount) {
  totalCol <- paste0("N total patients (", colSuffix, ")")
  usersCol <- paste0("N valproate users (", colSuffix, ")")
  rateCol  <- paste0("Rate of valproate use (", colSuffix, ")")

  data |>
    dplyr::filter(.data$denominator_sex == sexLabel) |>
    dplyr::mutate(
      Year    = as.integer(format(as.Date(.data$prevalence_start_date), "%Y")),
      n_total = as.integer(.data$denominator_count),
      n_users = as.integer(.data$outcome_count),
      n_total = dplyr::if_else(.data$n_total < minCellCount, NA_integer_, .data$n_total),
      n_users = dplyr::if_else(.data$n_users < minCellCount, NA_integer_, .data$n_users),
      rate    = dplyr::if_else(
        is.na(.data$n_total) | is.na(.data$n_users), NA_real_, as.numeric(.data$prevalence)
      )
    ) |>
    dplyr::select(
      "Year",
      !!totalCol := "n_total",
      !!usersCol := "n_users",
      !!rateCol  := "rate"
    ) |>
    dplyr::arrange(.data$Year)
}
