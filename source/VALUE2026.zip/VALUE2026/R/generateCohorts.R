#' Generate the valproate outcome cohort at a site
#'
#' @description
#' Builds the study's outcome cohort (valproate exposure) from the cohort
#' definition bundled with this package (`inst/cohorts/valproate.json`) and
#' registers it into the `cdm` object. No ATLAS/WebAPI instance is required
#' at the collaborating site -- the cohort JSON travels with the package.
#'
#' This uses [CohortGenerator::generateCohortSet()] (via
#' [DatabaseConnector::createConnectionDetails()], JDBC) rather than
#' [CDMConnector::generateCohortSet()], because the latter can silently
#' return zero rows on databases (e.g. SQL Server) where temp tables lose
#' scope between calls. CohortGenerator batches all SQL in one session and
#' supports `tempEmulationSchema`, which avoids that failure mode.
#'
#' @param cdm A `cdm_reference` from [connectSite()].
#' @param connectionDetails A `connectionDetails` object from
#'   [DatabaseConnector::createConnectionDetails()], pointing at the same
#'   database as `cdm`. Built by the caller -- never stored by this package.
#' @param cdmDatabaseSchema Fully-qualified CDM schema (e.g.
#'   `"my_catalog.dbo"`), as used by DatabaseConnector/CohortGenerator SQL.
#' @param cohortDatabaseSchema Fully-qualified write schema for cohort
#'   tables, as used by DatabaseConnector/CohortGenerator SQL.
#' @param tempEmulationSchema Schema used to emulate temp tables on DBMSs
#'   that need it (e.g. `"my_catalog.dbo"` for some SQL Server setups, or
#'   `NULL` if not needed for the site's DBMS).
#' @param outcomeTableName Name of the cohort table to create for the
#'   outcome cohort. Defaults to `"value2026_outcome"`.
#'
#' @return `cdm`, with the outcome cohort table (named `outcomeTableName`)
#'   added and registered as a cohort table.
#' @export
generateCohorts <- function(cdm,
                             connectionDetails,
                             cdmDatabaseSchema,
                             cohortDatabaseSchema,
                             tempEmulationSchema = NULL,
                             outcomeTableName = "value2026_outcome") {
  checkmate::assert_string(cdmDatabaseSchema)
  checkmate::assert_string(cohortDatabaseSchema)
  checkmate::assert_string(outcomeTableName)

  cohortJsonPath <- system.file(
    "cohorts", "valproate.json",
    package = "VALUE2026"
  )
  if (!nzchar(cohortJsonPath)) {
    cli::cli_abort("Could not locate bundled cohort definition {.file valproate.json}.")
  }

  cli::cli_inform("Building cohort SQL from bundled cohort definition...")
  cohortJson <- paste(readLines(cohortJsonPath, warn = FALSE), collapse = "\n")
  cohortExpression <- CirceR::cohortExpressionFromJson(cohortJson)
  cohortSql <- CirceR::buildCohortQuery(
    cohortExpression,
    options = CirceR::createGenerateOptions(generateStats = FALSE)
  )

  cohortDefinitionSet <- CohortGenerator::createEmptyCohortDefinitionSet()
  cohortDefinitionSet <- rbind(
    cohortDefinitionSet,
    data.frame(
      cohortId         = 1L,
      cohortName       = "valproate",
      json             = cohortJson,
      sql              = cohortSql,
      stringsAsFactors = FALSE
    )
  )

  cohortTableNames <- CohortGenerator::getCohortTableNames(cohortTable = outcomeTableName)

  cli::cli_inform("Creating cohort tables in {.val {cohortDatabaseSchema}}...")
  CohortGenerator::createCohortTables(
    connectionDetails    = connectionDetails,
    cohortDatabaseSchema = cohortDatabaseSchema,
    cohortTableNames     = cohortTableNames,
    incremental          = FALSE
  )

  cli::cli_inform("Generating valproate outcome cohort...")
  CohortGenerator::generateCohortSet(
    connectionDetails    = connectionDetails,
    cdmDatabaseSchema    = cdmDatabaseSchema,
    cohortDatabaseSchema = cohortDatabaseSchema,
    cohortTableNames     = cohortTableNames,
    cohortDefinitionSet  = cohortDefinitionSet,
    tempEmulationSchema  = tempEmulationSchema,
    incremental          = FALSE
  )

  cdm <- .registerOutcomeCohort(
    cdm                   = cdm,
    connectionDetails     = connectionDetails,
    cohortDatabaseSchema  = cohortDatabaseSchema,
    outcomeTableName      = outcomeTableName
  )

  n <- omopgenerics::cohortCount(cdm[[outcomeTableName]])
  cli::cli_inform(c("v" = "Valproate outcome cohort generated: {sum(n$number_records)} records."))

  cdm
}

#' @noRd
.registerOutcomeCohort <- function(cdm, connectionDetails, cohortDatabaseSchema, outcomeTableName) {
  con <- DatabaseConnector::connect(connectionDetails)
  on.exit(DatabaseConnector::disconnect(con))

  outcomeRows <- DatabaseConnector::renderTranslateQuerySql(
    connection = con,
    sql = "SELECT CAST(cohort_definition_id AS INT) AS cohort_definition_id,
                  CAST(subject_id AS BIGINT)        AS subject_id,
                  cohort_start_date, cohort_end_date
           FROM @cohort_database_schema.@outcome_table_name",
    cohort_database_schema = cohortDatabaseSchema,
    outcome_table_name     = outcomeTableName,
    snakeCaseToCamelCase   = TRUE
  )
  names(outcomeRows) <- tolower(names(outcomeRows))
  outcomeRows$cohort_definition_id <- as.integer(outcomeRows$cohort_definition_id)
  outcomeRows$subject_id <- as.integer(outcomeRows$subject_id)

  cdm <- omopgenerics::insertTable(
    cdm = cdm, name = outcomeTableName, table = outcomeRows, overwrite = TRUE
  )

  cdm[[outcomeTableName]] <- omopgenerics::newCohortTable(
    table        = cdm[[outcomeTableName]],
    cohortSetRef = dplyr::tibble(cohort_definition_id = 1L, cohort_name = "valproate")
  )

  cdm
}
