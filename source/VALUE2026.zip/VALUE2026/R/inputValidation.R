#' @noRd
.validateExecuteArgs <- function(cdmName,
                                  cdmDatabaseSchema,
                                  cohortDatabaseSchema,
                                  outputFolder,
                                  startDate,
                                  endDate,
                                  ageMin,
                                  ageMax,
                                  minCellCount) {
  checkmate::assert_string(cdmName, min.chars = 1)
  checkmate::assert_string(cdmDatabaseSchema, min.chars = 1)
  checkmate::assert_string(cohortDatabaseSchema, min.chars = 1)
  checkmate::assert_string(outputFolder, min.chars = 1)
  checkmate::assert_date(startDate)
  checkmate::assert_date(endDate)
  checkmate::assert_int(ageMin, lower = 0, upper = 120)
  checkmate::assert_int(ageMax, lower = ageMin, upper = 120)
  checkmate::assert_int(minCellCount, lower = 0)

  if (endDate <= startDate) {
    cli::cli_abort("{.arg endDate} ({endDate}) must be after {.arg startDate} ({startDate}).")
  }

  invisible(TRUE)
}
