#' Export VALUE2026 study results to CSV and Excel
#'
#' @description
#' Writes the prevalence summary tables, characterization table, and any
#' plots to `outputFolder`, in the standard file layout shared across
#' VALUE2026 data collaborators (so results can be pooled/compared across
#' sites without renaming files).
#'
#' @param outputFolder Directory to write results to. Created if it does not
#'   exist.
#' @param prevalenceSummary The list returned by [summarisePrevalence()]
#'   (with `bySex` and `bothSexes` tibbles).
#' @param table1 Optional characterization table (the `table1` element from
#'   [runCharacterization()]). If `NULL`, no characterization file is written.
#' @param plots Optional named list of `ggplot` objects to save as PNGs.
#'   Names become file names (e.g. `list(Incidence_by_sex = p1)` writes
#'   `Incidence_by_sex.png`).
#' @param drugUtilisationTidy Optional tidy drug utilization table from
#'   [tidyDrugUtilisation()]. If supplied, written to
#'   `valproate_drug_utilization.csv`/`.xlsx`.
#' @param drugUtilisationByYear Optional tibble from
#'   [summariseDrugUtilisationByYear()]. If supplied, written to
#'   `valproate_drug_utilization_by_year.csv`.
#' @param prescriptionRate Optional list from [summarisePrescriptionRate()]
#'   (with `overall` and `bySex` tibbles). If supplied, written to
#'   `valproate_prescription_rate_both.csv`/`_by_sex.csv`.
#' @param exposurePerPatient Optional list from
#'   [summariseExposurePerPatient()] (with `overall` and `bySex` tibbles).
#'   If supplied, written to
#'   `valproate_exposure_per_patient_both.csv`/`_by_sex.csv`.
#'
#' @return (Invisibly) the `outputFolder` path.
#' @export
exportResults <- function(outputFolder, prevalenceSummary, table1 = NULL, plots = NULL,
                           drugUtilisationTidy = NULL, drugUtilisationByYear = NULL,
                           prescriptionRate = NULL, exposurePerPatient = NULL) {
  checkmate::assert_string(outputFolder)
  dir.create(outputFolder, showWarnings = FALSE, recursive = TRUE)

  cli::cli_inform("Writing results to {.path {outputFolder}}...")

  utils::write.csv(
    prevalenceSummary$bySex,
    file.path(outputFolder, "valproate_prevalence_male_female.csv"),
    row.names = FALSE
  )
  utils::write.csv(
    prevalenceSummary$bothSexes,
    file.path(outputFolder, "valproate_prevalence_both_sexes.csv"),
    row.names = FALSE
  )

  wb <- openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb, "Male_Female")
  openxlsx::writeData(wb, "Male_Female", prevalenceSummary$bySex)
  openxlsx::addWorksheet(wb, "Both_sexes")
  openxlsx::writeData(wb, "Both_sexes", prevalenceSummary$bothSexes)
  openxlsx::saveWorkbook(
    wb, file.path(outputFolder, "valproate_prevalence.xlsx"), overwrite = TRUE
  )

  if (!is.null(table1)) {
    charWb <- openxlsx::createWorkbook()
    openxlsx::addWorksheet(charWb, "Table1_Characteristics")
    openxlsx::writeData(charWb, "Table1_Characteristics", table1)
    openxlsx::saveWorkbook(
      charWb, file.path(outputFolder, "valproate_characterization.xlsx"), overwrite = TRUE
    )
  }

  if (!is.null(plots)) {
    for (plotName in names(plots)) {
      ggplot2::ggsave(
        file.path(outputFolder, paste0(plotName, ".png")),
        plots[[plotName]], width = 14, height = 7, dpi = 450
      )
    }
  }

  if (!is.null(drugUtilisationTidy)) {
    utils::write.csv(
      drugUtilisationTidy,
      file.path(outputFolder, "valproate_drug_utilization.csv"),
      row.names = FALSE
    )
    duWb <- openxlsx::createWorkbook()
    openxlsx::addWorksheet(duWb, "Drug_Utilization")
    openxlsx::writeData(duWb, "Drug_Utilization", drugUtilisationTidy)
    openxlsx::saveWorkbook(
      duWb, file.path(outputFolder, "valproate_drug_utilization.xlsx"), overwrite = TRUE
    )
  }

  if (!is.null(drugUtilisationByYear)) {
    utils::write.csv(
      drugUtilisationByYear,
      file.path(outputFolder, "valproate_drug_utilization_by_year.csv"),
      row.names = FALSE
    )
  }

  if (!is.null(prescriptionRate)) {
    utils::write.csv(
      prescriptionRate$overall,
      file.path(outputFolder, "valproate_prescription_rate_both.csv"),
      row.names = FALSE
    )
    utils::write.csv(
      prescriptionRate$bySex,
      file.path(outputFolder, "valproate_prescription_rate_by_sex.csv"),
      row.names = FALSE
    )
  }

  if (!is.null(exposurePerPatient)) {
    utils::write.csv(
      exposurePerPatient$overall,
      file.path(outputFolder, "valproate_exposure_per_patient_both.csv"),
      row.names = FALSE
    )
    utils::write.csv(
      exposurePerPatient$bySex,
      file.path(outputFolder, "valproate_exposure_per_patient_by_sex.csv"),
      row.names = FALSE
    )
  }

  cli::cli_inform(c("v" = "Results written to {.path {outputFolder}}."))
  invisible(outputFolder)
}
