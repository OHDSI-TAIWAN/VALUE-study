#' Generate the study denominator population
#'
#' @description
#' Builds the denominator cohort used for both incidence and prevalence:
#' people aged `ageMin`-`ageMax`, of the requested sexes, with at least
#' `daysPriorObservation` days of prior observation, over `startDate` to
#' `endDate`.
#'
#' @param cdm A `cdm_reference`, as returned by [connectSite()].
#' @param startDate,endDate Study period bounds (`Date`).
#' @param ageMin,ageMax Integer age bounds (inclusive), applied as
#'   time-varying age.
#' @param sex Character vector of sex strata to generate, e.g.
#'   `c("Both", "Female", "Male")`.
#' @param daysPriorObservation Minimum required prior observation, in days.
#' @param denominatorName Name to register the denominator cohort table
#'   under in `cdm`. Defaults to `"value2026_denominator"`.
#'
#' @return `cdm`, with the denominator cohort table added.
#' @export
generateDenominator <- function(cdm,
                                 startDate,
                                 endDate,
                                 ageMin = 18,
                                 ageMax = 49,
                                 sex = c("Both", "Female", "Male"),
                                 daysPriorObservation = 365,
                                 denominatorName = "value2026_denominator") {
  checkmate::assert_date(startDate)
  checkmate::assert_date(endDate)
  checkmate::assert_int(ageMin, lower = 0)
  checkmate::assert_int(ageMax, lower = ageMin)
  checkmate::assert_character(sex, min.len = 1)
  checkmate::assert_int(daysPriorObservation, lower = 0)

  cli::cli_inform("Generating denominator population (ages {ageMin}-{ageMax}, {paste(sex, collapse = '/')})...")

  cdm <- IncidencePrevalence::generateDenominatorCohortSet(
    cdm                  = cdm,
    name                 = denominatorName,
    cohortDateRange      = c(startDate, endDate),
    ageGroup             = list(c(ageMin, ageMax)),
    sex                  = sex,
    daysPriorObservation = daysPriorObservation
  )

  n <- omopgenerics::cohortCount(cdm[[denominatorName]])
  cli::cli_inform(c("v" = "Denominator generated: {sum(n$number_records)} records across {nrow(n)} strata."))

  cdm
}

#' Estimate annual incidence of valproate use
#'
#' @param cdm A `cdm_reference` with denominator and outcome cohorts already
#'   generated (see [generateDenominator()] and [generateCohorts()]).
#' @param denominatorTable Name of the denominator cohort table in `cdm`.
#' @param outcomeTable Name of the outcome cohort table in `cdm`.
#' @param outcomeWashout Washout period (days) applied before a person can
#'   re-enter as a new user.
#' @param repeatedEvents Whether repeated incident events per person are
#'   counted (passed to [IncidencePrevalence::estimateIncidence()]).
#'
#' @return An incidence result object (`omopgenerics` summarised result),
#'   as returned by [IncidencePrevalence::estimateIncidence()].
#' @export
estimateStudyIncidence <- function(cdm,
                                    denominatorTable = "value2026_denominator",
                                    outcomeTable = "value2026_outcome",
                                    outcomeWashout = 365,
                                    repeatedEvents = TRUE) {
  cli::cli_inform("Estimating annual incidence of valproate use...")

  inc <- IncidencePrevalence::estimateIncidence(
    cdm                       = cdm,
    denominatorTable          = denominatorTable,
    outcomeTable              = outcomeTable,
    interval                  = "years",
    outcomeWashout            = outcomeWashout,
    repeatedEvents            = repeatedEvents,
    completeDatabaseIntervals = TRUE
  )

  cli::cli_inform(c("v" = "Incidence estimation complete."))
  inc
}

#' Estimate annual period prevalence of valproate use
#'
#' @inheritParams estimateStudyIncidence
#'
#' @return A period prevalence result object (`omopgenerics` summarised
#'   result), as returned by
#'   [IncidencePrevalence::estimatePeriodPrevalence()].
#' @export
estimateStudyPrevalence <- function(cdm,
                                     denominatorTable = "value2026_denominator",
                                     outcomeTable = "value2026_outcome") {
  cli::cli_inform("Estimating annual period prevalence of valproate use...")

  prev <- IncidencePrevalence::estimatePeriodPrevalence(
    cdm                       = cdm,
    denominatorTable          = denominatorTable,
    outcomeTable              = outcomeTable,
    interval                  = "years",
    fullContribution          = FALSE,
    completeDatabaseIntervals = TRUE
  )

  cli::cli_inform(c("v" = "Prevalence estimation complete."))
  prev
}
