#' VALUE2026: Incidence and Prevalence of Valproate Use Across APAC OMOP-CDM Databases
#'
#' @description
#' VALUE2026 is an OHDSI network study package supporting the VALUE study:
#' "Regulatory approaches to valproate across Asia-Pacific countries using
#' OMOP-CDM". It estimates the incidence, period prevalence, and baseline
#' characteristics of valproate use among people of reproductive age (18-49)
#' at each participating data partner, using OMOP standard concepts for
#' sodium valproate / valproate / valproic acid (RxNorm ingredient 745466).
#'
#' See `vignette("value2026")` for the study background and a full
#' walkthrough, and `inst/CodeToRun.R` (via
#' `system.file("CodeToRun.R", package = "VALUE2026")`) for the template
#' collaborators copy and fill in with their own site's connection details.
#'
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom rlang .data :=
## usethis namespace: end
NULL
