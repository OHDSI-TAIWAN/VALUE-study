#' Summarise drug utilization of valproate users
#'
#' @description
#' Summarises duration, dose, and treatment-episode metrics (days
#' prescribed/exposed, initial exposure duration, cumulative/initial
#' quantity, number of eras/exposures, time to exposure) for the valproate
#' outcome cohort, using [DrugUtilisation::summariseDrugUtilisation()].
#' Consecutive prescriptions with gaps under `gapEra` days are concatenated
#' into continuous treatment episodes, matching Bellas et al. (2025).
#'
#' @param cdm A `cdm_reference` with the outcome cohort already generated
#'   (see [generateCohorts()]).
#' @param outcomeTable Name of the outcome cohort table in `cdm`.
#' @param ingredientConceptId RxNorm ingredient concept id for valproate.
#'   Defaults to `745466`.
#' @param gapEra Maximum gap (days) between prescriptions to still be
#'   concatenated into one continuous treatment era. Defaults to `30`.
#'
#' @return A summarised drug utilization result object (`omopgenerics`
#'   summarised result), as returned by
#'   [DrugUtilisation::summariseDrugUtilisation()].
#' @export
summariseStudyDrugUtilisation <- function(cdm,
                                           outcomeTable = "value2026_outcome",
                                           ingredientConceptId = 745466,
                                           gapEra = 30) {
  checkmate::assert_string(outcomeTable)
  checkmate::assert_int(ingredientConceptId)
  checkmate::assert_int(gapEra, lower = 0)

  cli::cli_inform("Summarising valproate drug utilization...")

  dusResult <- cdm[[outcomeTable]] |>
    DrugUtilisation::summariseDrugUtilisation(
      ingredientConceptId = ingredientConceptId,
      gapEra              = gapEra
    )

  cli::cli_inform(c("v" = "Drug utilization summary complete."))
  dusResult
}

#' Tidy a drug utilization result into a readable summary table
#'
#' @param drugUtilisationResult A result from
#'   [summariseStudyDrugUtilisation()].
#'
#' @return A tibble with `Variable`, `Estimate`, and `Value` columns.
#' @export
tidyDrugUtilisation <- function(drugUtilisationResult) {
  drugUtilisationResult |>
    dplyr::as_tibble() |>
    dplyr::filter(
      .data$estimate_name %in% c("count", "min", "q25", "median", "q75", "max", "mean", "sd")
    ) |>
    dplyr::mutate(estimate_value = as.numeric(.data$estimate_value)) |>
    dplyr::select(
      Variable = "variable_name",
      Estimate = "estimate_name",
      Value    = "estimate_value"
    ) |>
    dplyr::arrange(.data$Variable, .data$Estimate)
}

#' Summarise drug utilization trends by index year
#'
#' @description
#' Stratifies [DrugUtilisation::summariseDrugUtilisation()] by index year
#' (and sex) to show how treatment patterns change over calendar time, then
#' extracts median values per year for the key clinical metrics used in the
#' standard trend plot (see [plotDrugUtilisationTrendsByYear()]).
#'
#' @inheritParams summariseStudyDrugUtilisation
#' @param startDate Study start date; years before this are dropped from the
#'   trend output.
#'
#' @return A tibble with `year`, `variable_name`, and `value` columns
#'   (median values per metric per year).
#' @export
summariseDrugUtilisationByYear <- function(cdm,
                                            outcomeTable = "value2026_outcome",
                                            ingredientConceptId = 745466,
                                            gapEra = 30,
                                            startDate) {
  checkmate::assert_string(outcomeTable)
  checkmate::assert_date(startDate)

  cli::cli_inform("Summarising valproate drug utilization trends by year...")

  dusByYear <- cdm[[outcomeTable]] |>
    PatientProfiles::addDemographics() |>
    dplyr::mutate(index_year = lubridate::year(.data$cohort_start_date)) |>
    DrugUtilisation::summariseDrugUtilisation(
      ingredientConceptId = ingredientConceptId,
      gapEra              = gapEra,
      strata              = list("index_year", "sex")
    )

  metricLabels <- c(
    "days prescribed"  = "Days prescribed (median)",
    "days exposed"     = "Days exposed (median)",
    "number exposures" = "Number of exposures (median)",
    "number eras"      = "Number of eras (median)",
    "time to exposure" = "Time to exposure (median, days)"
  )

  dusYearTidy <- dusByYear |>
    dplyr::as_tibble() |>
    dplyr::filter(
      .data$strata_name   == "index_year",
      .data$estimate_name == "median",
      .data$variable_name %in% names(metricLabels)
    ) |>
    dplyr::mutate(
      year          = as.integer(.data$strata_level),
      value         = as.numeric(.data$estimate_value),
      variable_name = dplyr::recode(.data$variable_name, !!!metricLabels)
    ) |>
    dplyr::filter(.data$year >= as.integer(format(startDate, "%Y"))) |>
    dplyr::select("year", "variable_name", "value")

  cli::cli_inform(c("v" = "Drug utilization trends summarised ({nrow(dusYearTidy)} rows)."))
  dusYearTidy
}

#' Prescription rate per 1,000 population, by year
#'
#' @description
#' Counts valproate prescriptions (`drug_exposure` records with
#' `drug_concept_id = ingredientConceptId`) per calendar year, overall and
#' by sex, and expresses them as a rate per 1,000 population using the
#' denominator counts from [summarisePrevalence()].
#'
#' Uses raw SQL directly against `drug_exposure`, since no OHDSI package
#' provides this specific count.
#'
#' @param con An open DBI connection to the site's OMOP CDM database.
#' @param cdmDatabaseSchema Fully-qualified CDM schema (e.g.
#'   `"my_catalog.dbo"`), as used in raw SQL.
#' @param ingredientConceptId RxNorm ingredient concept id for valproate.
#'   Defaults to `745466`.
#' @param startDate,endDate Study period bounds (`Date`).
#' @param prevalenceSummary The list returned by [summarisePrevalence()]
#'   (with `bySex` and `bothSexes` tibbles), used as the population
#'   denominator.
#'
#' @return A list with two tibbles:
#'   \describe{
#'     \item{`overall`}{One row per year: prescriptions, population, rate per 1,000.}
#'     \item{`bySex`}{One row per year per sex: prescriptions, population, rate per 1,000.}
#'   }
#' @export
summarisePrescriptionRate <- function(con,
                                       cdmDatabaseSchema,
                                       ingredientConceptId = 745466,
                                       startDate,
                                       endDate,
                                       prevalenceSummary) {
  checkmate::assert_date(startDate)
  checkmate::assert_date(endDate)

  cli::cli_inform("Computing valproate prescription rate by year...")

  schemaStr <- .schemaToString(cdmDatabaseSchema)

  rxPerYear <- DBI::dbGetQuery(con, sprintf("
    SELECT
      YEAR(CAST(drug_exposure_start_date AS DATE)) AS year,
      COUNT(*) AS n_prescriptions
    FROM %s.drug_exposure
    WHERE drug_concept_id = %d
      AND drug_exposure_start_date >= '%s'
      AND drug_exposure_start_date <= '%s'
    GROUP BY YEAR(CAST(drug_exposure_start_date AS DATE))
    ORDER BY year",
    schemaStr, ingredientConceptId,
    format(startDate, "%Y-01-01"), format(endDate, "%Y-12-31")
  ))

  rxPerYearSex <- DBI::dbGetQuery(con, sprintf("
    SELECT
      YEAR(CAST(de.drug_exposure_start_date AS DATE)) AS year,
      p.gender_concept_id,
      COUNT(*) AS n_prescriptions
    FROM %s.drug_exposure de
    JOIN %s.person p ON de.person_id = p.person_id
    WHERE de.drug_concept_id = %d
      AND de.drug_exposure_start_date >= '%s'
      AND de.drug_exposure_start_date <= '%s'
      AND p.gender_concept_id IN (8507, 8532)
    GROUP BY YEAR(CAST(de.drug_exposure_start_date AS DATE)), p.gender_concept_id
    ORDER BY year, p.gender_concept_id",
    schemaStr, schemaStr, ingredientConceptId,
    format(startDate, "%Y-01-01"), format(endDate, "%Y-12-31")
  )) |>
    dplyr::mutate(
      Sex = dplyr::case_when(
        .data$gender_concept_id == 8507 ~ "Male",
        .data$gender_concept_id == 8532 ~ "Female"
      )
    )

  overall <- rxPerYear |>
    dplyr::left_join(
      prevalenceSummary$bothSexes |>
        dplyr::select(Year, n_total = "N total patients (both)"),
      by = c("year" = "Year")
    ) |>
    dplyr::filter(!is.na(.data$n_total)) |>
    dplyr::mutate(rate_per_1000 = .data$n_prescriptions / .data$n_total * 1000)

  bySex <- rxPerYearSex |>
    dplyr::left_join(
      dplyr::bind_rows(
        prevalenceSummary$bySex |>
          dplyr::select(Year, n_total = "N total patients (male)") |>
          dplyr::mutate(Sex = "Male"),
        prevalenceSummary$bySex |>
          dplyr::select(Year, n_total = "N total patients (female)") |>
          dplyr::mutate(Sex = "Female")
      ),
      by = c("year" = "Year", "Sex")
    ) |>
    dplyr::filter(!is.na(.data$n_total)) |>
    dplyr::mutate(
      rate_per_1000 = .data$n_prescriptions / .data$n_total * 1000,
      Sex           = factor(.data$Sex, levels = c("Female", "Male"))
    )

  cli::cli_inform(c("v" = "Prescription rate computed ({nrow(overall)} years)."))
  list(overall = overall, bySex = bySex)
}

#' Drug exposure records per patient per year
#'
#' @description
#' Counts `drug_exposure` records per patient per calendar year -- a measure
#' of how intensively patients are prescribed valproate over time. Note this
#' counts `drug_exposure` *records*, not real-world prescriptions written;
#' depending on the ETL, one prescription may map to one or multiple rows.
#'
#' @inheritParams summarisePrescriptionRate
#'
#' @return A list with two tibbles:
#'   \describe{
#'     \item{`overall`}{One row per year: prescriptions, patients, exposures per patient.}
#'     \item{`bySex`}{One row per year per sex: prescriptions, patients, exposures per patient.}
#'   }
#' @export
summariseExposurePerPatient <- function(con,
                                         cdmDatabaseSchema,
                                         ingredientConceptId = 745466,
                                         startDate,
                                         endDate) {
  checkmate::assert_date(startDate)
  checkmate::assert_date(endDate)

  cli::cli_inform("Computing valproate exposure records per patient per year...")

  schemaStr <- .schemaToString(cdmDatabaseSchema)

  overall <- DBI::dbGetQuery(con, sprintf("
    SELECT
      YEAR(CAST(drug_exposure_start_date AS DATE)) AS year,
      COUNT(*) AS n_prescriptions,
      COUNT(DISTINCT person_id) AS n_patients,
      CAST(COUNT(*) AS FLOAT) / COUNT(DISTINCT person_id) AS rx_per_patient
    FROM %s.drug_exposure
    WHERE drug_concept_id = %d
      AND drug_exposure_start_date >= '%s'
      AND drug_exposure_start_date <= '%s'
    GROUP BY YEAR(CAST(drug_exposure_start_date AS DATE))
    ORDER BY year",
    schemaStr, ingredientConceptId,
    format(startDate, "%Y-01-01"), format(endDate, "%Y-12-31")
  ))

  bySex <- DBI::dbGetQuery(con, sprintf("
    SELECT
      YEAR(CAST(de.drug_exposure_start_date AS DATE)) AS year,
      p.gender_concept_id,
      COUNT(*) AS n_prescriptions,
      COUNT(DISTINCT de.person_id) AS n_patients,
      CAST(COUNT(*) AS FLOAT) / COUNT(DISTINCT de.person_id) AS rx_per_patient
    FROM %s.drug_exposure de
    JOIN %s.person p ON de.person_id = p.person_id
    WHERE de.drug_concept_id = %d
      AND de.drug_exposure_start_date >= '%s'
      AND de.drug_exposure_start_date <= '%s'
      AND p.gender_concept_id IN (8507, 8532)
    GROUP BY YEAR(CAST(de.drug_exposure_start_date AS DATE)), p.gender_concept_id
    ORDER BY year, p.gender_concept_id",
    schemaStr, schemaStr, ingredientConceptId,
    format(startDate, "%Y-01-01"), format(endDate, "%Y-12-31")
  )) |>
    dplyr::mutate(
      Sex = dplyr::case_when(
        .data$gender_concept_id == 8507 ~ "Male",
        .data$gender_concept_id == 8532 ~ "Female"
      ),
      Sex = factor(.data$Sex, levels = c("Female", "Male"))
    )

  cli::cli_inform(c("v" = "Exposure per patient computed ({nrow(overall)} years)."))
  list(overall = overall, bySex = bySex)
}
