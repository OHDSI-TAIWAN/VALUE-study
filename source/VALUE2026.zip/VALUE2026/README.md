# VALUE2026

<!-- badges: start -->
[![R CMD check](https://img.shields.io/badge/R%20CMD%20check-passing-brightgreen)](.)
<!-- badges: end -->

An [OHDSI](https://ohdsi.org) network study package supporting **VALUE**:
*Regulatory approaches to valproate across Asia-Pacific countries using OMOP-CDM*.

VALUE2026 estimates the incidence, period prevalence, and baseline characteristics of
valproate use among people of reproductive age (18-49) at each participating OMOP-CDM
data partner in the APAC region, so results can be compared consistently across sites
with differing regulatory histories.

## Study background

This study describes the real-world use of sodium valproate before, during, and after
multi-wave safety warnings among women and men of reproductive age, and examines how
differing regulatory approaches across Asia-Pacific countries have shaped prescribing
patterns -- including whether safety actions were followed by reductions in valproate
use and substitution with alternative treatments.

Valproate users are identified using the OMOP standard concept for the ingredient
**valproate** (RxNorm concept id `745466`, code `40254`) and all descendants, covering
both monotherapy and combination formulations. See `vignette("value2026")` for full
protocol details.

## Installation

```r
# install.packages("remotes")
remotes::install_github("Thanh-Phuc/VALUE2026")
```

## Quick start

VALUE2026 is designed so that participating sites run the study in a **single step**,
without writing any analysis code themselves.

1. Copy the `CodeToRun.R` template shipped with the package:

   ```r
   file.copy(
     system.file("CodeToRun.R", package = "VALUE2026"),
     "~/VALUE2026_CodeToRun.R"
   )
   ```

2. Open `~/VALUE2026_CodeToRun.R` and fill in **only** your site's database
   connection details and schema names (see comments in the file). Never type
   credentials directly into the script -- use environment variables.

3. Run the script. It calls the package's single entry point:

   ```r
   VALUE2026::execute(
     con                      = con,                   # your DBI connection
     connectionDetails        = connection_details,     # your DatabaseConnector details
     cdmName                  = "MySite",
     cdmDatabaseSchema        = cdm_database_schema,
     vocabularyDatabaseSchema = vocabulary_database_schema,
     writeDatabaseSchema      = write_database_schema,
     outputFolder             = "~/VALUE2026_results"
   )
   ```

4. Review the results in `outputFolder`, then share **only that folder** back with
   the study coordinating team.

No local ATLAS/WebAPI instance is required -- the valproate cohort definition is
bundled with the package (`inst/cohorts/valproate.json`) and converted to OHDSI-SQL
at runtime.

**Supported databases:** SQL Server and PostgreSQL, selected via a single `dbms`
variable at the top of `CodeToRun.R`.

## What gets computed

- **Denominator**: people aged 18-49, by sex, with >=365 days prior observation.
- **Incidence**: annual new-user incidence per 100,000 person-years (365-day washout).
- **Period prevalence**: annual proportion of the denominator with any valproate use.
- **Baseline characterization**: demographics, comorbidities, and co-medications in
  the prior year for valproate users (Table 1).

All results are exported with a configurable minimum cell count suppression
(default `5`) applied, so no small-cell patient-level information leaves the site.

## What gets shared

Only the contents of the local `outputFolder`:

- `valproate_prevalence_both_sexes.csv`, `valproate_prevalence_male_female.csv`
- `valproate_prevalence.xlsx`
- `valproate_characterization.xlsx`
- `Incidence_by_sex.png`, `Incidence_person_years.png`, `Prevalence_by_sex.png`

Database credentials, connection strings, and patient-level data never leave the
site and are never written to any of these files.

## Package structure

| Function | Purpose |
|---|---|
| `execute()` | Single entry point: runs the full pipeline end to end |
| `connectSite()` | Builds the CDM reference from a site's connection |
| `generateCohorts()` | Generates the valproate outcome cohort from the bundled definition |
| `generateDenominator()` | Generates the study denominator population |
| `estimateStudyIncidence()` / `estimateStudyPrevalence()` | Core epidemiological estimates |
| `runCharacterization()` | Baseline characterization (Table 1) |
| `summarisePrevalence()` | Annual summary tables with cell suppression |
| `exportResults()` | Writes CSV/Excel/plot outputs |
| `plotIncidenceBySex()` / `plotIncidencePersonYears()` / `plotPrevalenceBySex()` | Standard study plots |

## License

Apache License (>= 2)
