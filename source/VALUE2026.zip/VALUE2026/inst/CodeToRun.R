# =============================================================================
# VALUE2026 -- CodeToRun template
#
# Study: Regulatory approaches to valproate across Asia-Pacific countries
#        using OMOP-CDM (the "VALUE" study).
#
# Supports SQL Server and PostgreSQL out of the box. Set `dbms` below to
# switch between them -- everything else in this file adapts automatically.
#
# INSTRUCTIONS FOR DATA PARTNERS
#   1. Copy this file out of the package folder to somewhere private on your
#      machine (it is NOT meant to be edited inside the installed package).
#   2. Set `dbms` to "sql server" or "postgresql", then fill in the
#      "Site-specific settings" section below with YOUR site's connection
#      details and schema names.
#   3. Do NOT type credentials directly into this file. Set them as
#      environment variables first (see below), or in a private, gitignored
#      .Renviron file that is never shared or committed anywhere.
#   4. Run the whole script. VALUE2026::execute() does everything else:
#      generates the cohort, estimates incidence/prevalence, runs baseline
#      characterization, builds plots, and writes results to `outputFolder`.
#   5. Share only the contents of `outputFolder` back to the study
#      coordinating team -- never this script, your connection details, or
#      raw patient-level data.
# =============================================================================

# ---- 0. Install (one-time) --------------------------------------------------
# install.packages("remotes")
# remotes::install_github("<org>/VALUE2026")
#
# DatabaseConnector JDBC drivers (one-time, per DBMS you use):
#   DatabaseConnector::downloadJdbcDrivers("sql server", pathToDriver = "~/.config/jdbc")
#   DatabaseConnector::downloadJdbcDrivers("postgresql", pathToDriver = "~/.config/jdbc")

library(VALUE2026)
library(DBI)
library(DatabaseConnector)


# ---- 1. Site-specific settings ----------------------------------------------
# Set this to match your database: "sql server" or "postgresql".
dbms <- "sql server"   # or: "postgresql"

# Read credentials from environment variables -- set these in your shell
# profile or a private .Renviron, never in this script.
#   Sys.setenv(VALUE2026_DB_HOST = "...")
#   Sys.setenv(VALUE2026_DB_USER = "...")
#   Sys.setenv(VALUE2026_DB_PASSWORD = "...")

db_host     <- Sys.getenv("VALUE2026_DB_HOST")
db_port     <- Sys.getenv("VALUE2026_DB_PORT", if (dbms == "postgresql") "5432" else "1433")
db_user     <- Sys.getenv("VALUE2026_DB_USER")
db_password <- Sys.getenv("VALUE2026_DB_PASSWORD")
db_name     <- Sys.getenv("VALUE2026_DB_NAME")     # database name

cdm_name <- "MyDatabase"                            # short display name, e.g. "TMUCRD"

# Schemas:
#  - SQL Server (uses catalogs): c(catalog = ..., schema = ...)
#  - PostgreSQL (schema only, single database): a plain string, e.g. "cdm"
if (dbms == "postgresql") {
  cdm_database_schema        <- "cdm"
  vocabulary_database_schema <- "cdm"
  write_database_schema      <- "results"
} else {
  cdm_database_schema        <- c(catalog = db_name, schema = "dbo")
  vocabulary_database_schema <- c(catalog = db_name, schema = "dbo")
  write_database_schema      <- c(catalog = db_name, schema = "results")
}

# Only needed for DBMSs that require temp table emulation (rare; e.g. some
# SQL Server setups, or Redshift/Snowflake). Set to NULL if not needed --
# PostgreSQL and most SQL Server setups do not need this.
temp_emulation_schema <- NULL

output_dir <- "~/VALUE2026_results"


# ---- 2. Open connections ----------------------------------------------------
# `con`: a plain DBI connection, used to build the cdm_reference.
# `connectionDetails`: a DatabaseConnector (JDBC) connection, used internally
# for cohort generation and characterization.
if (dbms == "postgresql") {
  library(RPostgres)

  con <- DBI::dbConnect(
    RPostgres::Postgres(),
    host     = db_host,
    port     = as.integer(db_port),
    dbname   = db_name,
    user     = db_user,
    password = db_password
  )

  connection_details <- DatabaseConnector::createConnectionDetails(
    dbms             = "postgresql",
    connectionString = paste0(
      "jdbc:postgresql://", db_host, ":", db_port, "/", db_name
    ),
    user         = db_user,
    password     = db_password,
    pathToDriver = "~/.config/jdbc"
  )
} else {
  library(odbc)

  con <- DBI::dbConnect(
    odbc::odbc(),
    Driver                 = "ODBC Driver 18 for SQL Server",
    Server                 = paste0("tcp:", db_host, ",", db_port),
    Database               = db_name,
    UID                    = db_user,
    PWD                    = db_password,
    Encrypt                = "yes",
    TrustServerCertificate = "yes"
  )

  connection_details <- DatabaseConnector::createConnectionDetails(
    dbms             = "sql server",
    connectionString = paste0(
      "jdbc:sqlserver://", db_host, ":", db_port,
      ";databaseName=", db_name,
      ";encrypt=true;trustServerCertificate=true"
    ),
    user         = db_user,
    password     = db_password,
    pathToDriver = "~/.config/jdbc"
  )
}


# ---- 3. Run the study --------------------------------------------------------
VALUE2026::execute(
  con                      = con,
  connectionDetails        = connection_details,
  cdmName                  = cdm_name,
  cdmDatabaseSchema        = cdm_database_schema,
  vocabularyDatabaseSchema = vocabulary_database_schema,
  writeDatabaseSchema      = write_database_schema,
  outputFolder             = output_dir,
  tempEmulationSchema      = temp_emulation_schema

  # Optional study-parameter overrides (defaults match the VALUE protocol):
  # startDate = as.Date("2005-01-01"), endDate = as.Date("2023-12-31"),
  # ageMin = 18, ageMax = 49, minCellCount = 5,
  # characterize = TRUE, drugUtilisation = TRUE,
  # ingredientConceptId = 745466, gapEra = 30
)

cat("Done. Results are in:", output_dir, "\n")
cat("Please review the exported files, then share ONLY that folder with the study team.\n")


# ---- 4. Disconnect -----------------------------------------------------------
DBI::dbDisconnect(con)
